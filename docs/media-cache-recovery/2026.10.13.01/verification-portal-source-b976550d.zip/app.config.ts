export default {
  logoUrl: "https://claudetool.app/manus-storage/ccti-icon_dc61d99c.svg"
};
