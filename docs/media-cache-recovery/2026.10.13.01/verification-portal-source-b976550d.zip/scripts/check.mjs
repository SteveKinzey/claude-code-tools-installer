import { readdir, readFile } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import assert from 'node:assert/strict';

async function inspect(directory) {
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const path = `${directory}/${entry.name}`;
    if (entry.isDirectory()) await inspect(path);
    else if (path.endsWith('.mjs')) {
      const result = spawnSync(process.execPath, ['--check', path], { encoding: 'utf8' });
      assert.equal(result.status, 0, result.stderr);
      if (path.startsWith('src/client/')) {
        const text = await readFile(path, 'utf8');
        assert(!/innerHTML|\bfetch\s*\(|XMLHttpRequest|sendBeacon|localStorage|serviceWorker/.test(text), `Unsafe browser capability in ${path}`);
      }
    }
  }
}
await inspect('src'); await inspect('scripts'); await inspect('tests');
for (const file of ['suite.json','native-caption.json','caption-http.json','references.json']) JSON.parse(await readFile(`content/${file}`, 'utf8'));
console.log('Check-only diagnostics passed: Node syntax, JSON parsing and browser capability boundaries. Native LSP unavailable (missing typescript-language-server); no LSP-clean claim.');
