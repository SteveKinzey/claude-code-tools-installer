import http from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { resolve, extname } from 'node:path';
import { fileURLToPath } from 'node:url';

export const mimeTypes = {'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml','.md':'text/markdown; charset=utf-8'};
export function createPreview(root = resolve('dist')) {
  return http.createServer(async (request,response) => {
    response.setHeader('X-Content-Type-Options','nosniff');
    if (!['GET','HEAD'].includes(request.method)) { response.writeHead(405,{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store','Allow':'GET, HEAD'});return response.end('Method not allowed'); }
    try {
      const raw = decodeURIComponent(request.url.split('?')[0]);
      if (raw.includes('..') || raw.includes('\\')) throw new Error('Invalid path');
      const path = resolve(root,`.${raw==='/'?'/index.html':raw}`);
      if (!path.startsWith(`${root}/`)) throw new Error('Outside root');
      if (!(await stat(path)).isFile()) throw new Error('Not a file');
      const bytes = await readFile(path);
      response.writeHead(200,{'Content-Type':mimeTypes[extname(path)]||'application/octet-stream','Content-Length':bytes.length,'Cache-Control':path.endsWith('.html')||path.endsWith('manus-routes.json')||path.endsWith('release-manifest.json')?'no-cache':'public, max-age=7776000, immutable'});
      response.end(request.method==='HEAD'?undefined:bytes);
    } catch {
      response.writeHead(404,{'Content-Type':'text/plain; charset=utf-8','Cache-Control':'no-store'});
      response.end(request.method==='HEAD'?undefined:'Evidence file not found');
    }
  });
}
if (process.argv[1]===fileURLToPath(import.meta.url)) {
  const port = Number(process.env.PORT || 3000);
  const server = createPreview();
  server.on('error',error=>{console.error(error.message);process.exit(1);});
  server.listen(port,'127.0.0.1',()=>console.log(`Notebook preview ready at http://127.0.0.1:${port}`));
}
