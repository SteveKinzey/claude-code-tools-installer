import { mkdir, readFile, writeFile, rm } from 'node:fs/promises';
import { dirname } from 'node:path';
import { contents, digest, jsonBytes } from '../src/html.mjs';
import { overview, workflow } from '../src/components/overview-workflow.mjs';
import { testExplorer, captionEvidence } from '../src/components/tests-captions.mjs';
import { routing, downloads } from '../src/components/routing-downloads.mjs';

export const sourceMap = [
  ['scripts/build.mjs','Deterministic HTML assembly; full-byte digests and content-versioned assets/downloads.'],
  ['src/html.mjs','Escaping, code panels, numbered headings, shared navigation and SHA-256 utilities.'],
  ['src/components/overview-workflow.mjs','Recorded production outcome and five-gate manual workflow.'],
  ['src/components/tests-captions.mjs','20 Python/36 Node static rows, gaps, four cues and complete escaped JSON.'],
  ['src/components/routing-downloads.mjs','Production source responsibilities, qualified cache analysis and digest-labelled downloads.'],
  ['src/styles.css','Responsive notebook tokens, contents rail, mobile disclosure and visible keyboard focus.'],
  ['src/client/filter.mjs','Pure multi-term matching and hide/show of existing evidence rows.'],
  ['src/client/clipboard.mjs','Clipboard action, explicit status and manual-copy dialog fallback.'],
  ['src/client/main.mjs','Progressive enhancement wiring; no production requests or telemetry.'],
  ['content/*.json and content/handbook.md','Curated public-safe source data and reusable handbook.'],
  ['scripts/serve.mjs','Loopback-only static preview with strict port, correct MIME and non-HTML404.'],
  ['scripts/check.mjs and tests/portal.test.mjs','Check-only diagnostics and portal-specific rendering/data/interaction-contract tests.']
];
const output = 'dist';
await rm(output, { recursive: true, force: true });
await mkdir(output, { recursive: true });
async function put(path, bytes) {
  await mkdir(dirname(`${output}${path}`), { recursive: true });
  await writeFile(`${output}${path}`, bytes);
}
async function fingerprint(folder, stem, extension, bytes) {
  const sha256 = digest(bytes);
  const path = `/${folder}/${stem}-${sha256.slice(0,16)}.${extension}`;
  await put(path, bytes);
  return { path, bytes: bytes.length, sha256 };
}
const suite = JSON.parse(await readFile('content/suite.json','utf8'));
const native = JSON.parse(await readFile('content/native-caption.json','utf8'));
const http = JSON.parse(await readFile('content/caption-http.json','utf8'));
const references = JSON.parse(await readFile('content/references.json','utf8'));
const files = [];
for (const [id,title,description,format,bytes] of [
  ['handbook','Recovery workflow handbook','Reusable manual gates, exact scopes and cache/retention decisions.','Markdown',await readFile('content/handbook.md')],
  ['suite','Suite & assertion inventory','All20 Python modules and36 Node cases, helpers, gaps and saved-log provenance.','JSON',jsonBytes(suite)],
  ['native','Native caption evidence','Public-safe derivative with four cues and matching transcript.','JSON',jsonBytes(native)],
  ['http','Two-host caption HTTP evidence','Public-safe dated normal GET derivative; selected headers only.','JSON',jsonBytes(http)]
]) files.push({id,title,description,format,...await fingerprint('downloads',id,format==='JSON'?'json':'md',bytes)});
for (const file of files.filter(file=>file.format==='JSON')) await put(file.path.replace('/downloads/','/data/'),await readFile(`${output}${file.path}`));
const icon = await fingerprint('assets','ccti-icon','svg',await readFile('public/assets/ccti-icon.svg'));
const css = await fingerprint('assets','notebook','css',await readFile('src/styles.css'));
const filter = await fingerprint('assets','filter','mjs',await readFile('src/client/filter.mjs'));
const clipboard = await fingerprint('assets','clipboard','mjs',await readFile('src/client/clipboard.mjs'));
let client = await readFile('src/client/main.mjs','utf8');
client = client.replace('./filter.mjs',filter.path).replace('./clipboard.mjs',clipboard.path);
const javascript = await fingerprint('assets','notebook','mjs',Buffer.from(client));
const nativeDownload = files.find(file=>file.id==='native');
const html = `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>CCTI Verification & Workflows — Evidence Notebook</title><meta name="description" content="Dated CCTI caption evidence, a reusable recovery workflow, exact test assertion scopes and honest cache boundaries. A recorded notebook, not live monitoring."><meta name="theme-color" content="#f6f6f0"><meta property="og:title" content="CCTI Verification & Workflows"><meta property="og:description" content="Read what passed, what it proves, and where the evidence stops."><meta property="og:type" content="website"><link rel="icon" href="${icon.path}" type="image/svg+xml"><link rel="stylesheet" href="${css.path}"><script type="module" src="${javascript.path}"></script></head>
<body><a class="skip-link" href="#main">Skip to evidence</a><header class="site-header"><a class="brand" href="#overview"><img src="${icon.path}" alt="CCTI official terminal mark" width="37" height="37"><span>CCTI<small>VERIFICATION & WORKFLOWS</small></span></a><span class="header-note">INDEPENDENT EVIDENCE NOTEBOOK<br>RECEIPTS / 12 OCT 2026</span></header><div class="layout"><aside class="rail"><p class="eyebrow">IN THIS NOTEBOOK</p><nav class="contents" aria-label="Notebook contents">${contents()}</nav><p class="rail-note"><strong>Evidence before claims.</strong><br>Saved results, readable scopes.<br>No live health checks.</p><p class="rail-footer">STATIC BY DESIGN<br>NO TRACKING · NO PROBES</p></aside><main class="main" id="main"><details class="mobile-contents"><summary>Contents · six sections</summary><nav class="contents" aria-label="Mobile notebook contents">${contents()}</nav></details>${overview()}${workflow()}${testExplorer(suite)}${captionEvidence(native,nativeDownload)}${routing()}${downloads(files,references.sources,sourceMap)}<footer class="site-footer"><span>CCTI Verification & Workflows · independent static notebook<br>Production/staging remain separate. Dated evidence is not live status.</span><a href="#overview">Back to beginning ↑</a></footer></main></div><div id="copy-status" class="copy-status" role="status" aria-live="polite"></div><dialog class="copy-fallback" id="copy-fallback" aria-labelledby="copy-fallback-title"><h2 id="copy-fallback-title">Copy manually</h2><p>Your browser did not permit clipboard access. Select this text and use your usual copy shortcut.</p><label for="copy-fallback-text">Text to copy</label><textarea id="copy-fallback-text" readonly></textarea><button type="button">Close manual copy</button></dialog></body></html>\n`;
await put('/index.html',Buffer.from(html));
await put('/404.html',Buffer.from('<!doctype html><html lang="en"><meta charset="utf-8"><title>Not found — CCTI notebook</title><h1>Not found</h1><p>This evidence file does not exist.</p><a href="/">Return to notebook</a></html>\n'));
await put('/manus-routes.json',jsonBytes({routes:[{path:'/',title:'CCTI Verification & Workflows'}]}));
await put('/release-manifest.json',jsonBytes({schema_version:1,files:[...files,icon,css,filter,clipboard,javascript],sourceMap}));
console.log(`Static build complete:6 sections,20 Python modules,36 Node cases,4 cues,${files.length} fingerprinted downloads. No dependencies or external services.`);
