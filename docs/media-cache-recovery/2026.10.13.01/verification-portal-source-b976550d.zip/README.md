# CCTI Verification & Workflows

Independent, dependency-free static evidence notebook. Production receipts are dated 12 October 2026, not live monitoring. This website is separate from installer, marketing production and staging.

## Commands

Use Node 22+. No third-party runtime/build packages or dependency installation are required.

```sh
node scripts/check.mjs
node --test tests/*.test.mjs
node scripts/build.mjs
PORT=<session-declared-port> node scripts/serve.mjs
```

The HTTP regression test needs loopback socket permission. Preview binds only127.0.0.1 and fails on occupied ports. Keep the session port outside committed configuration. No production targets are contacted by tests.

## Exact source/component map

| File | Responsibility |
| --- | --- |
| `scripts/build.mjs` | Deterministic static assembly into `dist/`; full SHA-256 and fingerprinted CSS/JS/icon/data/download files. |
| `src/html.mjs` | HTML escaping, code panels, section headings, shared navigation, digests. |
| `src/components/overview-workflow.mjs` | Recorded production outcome, lineage and five manual recovery gates. |
| `src/components/tests-captions.mjs` | 20 Python module/36 Node case static rows, assertion gaps, four cues and complete escaped derivative JSON. |
| `src/components/routing-downloads.mjs` | Dated production file map, qualified cache analysis, download hashes and official references. |
| `src/styles.css` | Off-white/navy/mint design, desktop rail, mobile disclosure, local font fallbacks, focus and reduced motion. |
| `src/client/filter.mjs` | Pure multi-term matching and hide/show of existing rows. |
| `src/client/clipboard.mjs` | Exact clipboard text, live feedback and manual dialog fallback. |
| `src/client/main.mjs` | Progressive enhancement wiring; no network/persistence/telemetry APIs. |
| `content/suite.json` | Curated exact module/case accounting, helper scopes, gaps and saved-log provenance. |
| `content/native-caption.json` | Sanitized native caption/transcript derivative with original digest provenance. |
| `content/caption-http.json` | Sanitized two-host normal GET derivative. |
| `content/references.json` | Official sources and scope-qualified reference facts. |
| `content/handbook.md` | Public-safe reusable workflow handbook. |
| `scripts/serve.mjs` | Strict loopback static preview, correct JSON MIME, non-HTML404, HEAD/405 behavior. |
| `scripts/check.mjs` | Node syntax, JSON and browser-capability safety diagnostics. |
| `tests/portal.test.mjs` | 21 new-portal regression cases, separate from archived130Python/36Node counts. |
| `public/assets/ccti-icon.svg` | Exact official617-byte icon. |
| `app.config.ts` | Durable official project-logo metadata. |
| `plan.md`, `TODO.md` | Approved plan and complete outcome requirements. |

`dist/index.html` contains all six sections,56 inventory rows and full escaped JSON beforeJavaScript. Client modules enhance existing DOM only. Rendering uses Node functions, not React or Express. The preview server is never deployed; production uses managed static output.

## Identity and publication

The tool-issued `manus-webdev.json` selects this independent managed project. Use its own separate Managed Git through the website workflow. Preserve parent userGit and other website histories. Never force-push. The build contract is `node scripts/check.mjs && node scripts/build.mjs`, output `dist`. No Git metadata is needed during clean build.

Cache routes apply only to this notebook: fingerprinted assets/data/downloads are immutable; mutable page/release manifests revalidate. No SPA catch-all is declared. Hosted missing-file behavior still needs public verification rather than being inferred from local preview.

Original evidence remains outside this project and is unchanged. Public derivatives remove trace identifiers/unrelated headers and have separate hashes. No raw history, secrets, machine paths, private task links or skill archives belong in public output.

Optional font acquisition was denied; approved named local fallback stacks are used, with no third-party runtimefont dependencies. Native LSP launch was unavailable because typescript-language-server is absent; check-only Node/JSON/source diagnostics are the recorded fallback. Do not label that fallback LSP-clean.
