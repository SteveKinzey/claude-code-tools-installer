import { createHash } from 'node:crypto';

export const escapeHTML = value => String(value).replace(/[&<>"']/g, character => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
})[character]);
export const digest = bytes => createHash('sha256').update(bytes).digest('hex');
export const jsonBytes = value => Buffer.from(`${JSON.stringify(value, null, 2)}\n`);
export const code = value => `<code>${escapeHTML(value)}</code>`;
export const panel = (id, text, label = 'Read-only command') => `<div class="code-panel"><div class="code-heading"><span>${escapeHTML(label)}</span><button type="button" data-copy="${escapeHTML(id)}" hidden>Copy</button></div><pre id="${escapeHTML(id)}" tabindex="0">${escapeHTML(text)}</pre></div>`;
export const sectionHeading = (number, eyebrow, title, subtitle) => `<header class="section-heading"><span class="section-number">${number}</span><div><p class="eyebrow">${escapeHTML(eyebrow)}</p><h2>${escapeHTML(title)}</h2><p>${escapeHTML(subtitle)}</p></div></header>`;
export const sections = [
  ['overview', 'Recorded outcome'], ['workflow', 'Recovery workflow'], ['tests', 'Test explorer'],
  ['captions', 'Caption evidence'], ['routing', 'Routing & cache'], ['downloads', 'Downloads & sources']
];
export const contents = () => `<ol>${sections.map(([id, title], index) => `<li><a href="#${id}"><span>0${index + 1}</span>${title}</a></li>`).join('')}</ol>`;
