import { initializeFilters } from './filter.mjs';
import { initializeClipboard } from './clipboard.mjs';

initializeFilters(document);
initializeClipboard(document, navigator);
for (const control of document.querySelectorAll('[data-enhancement]')) control.hidden = false;
