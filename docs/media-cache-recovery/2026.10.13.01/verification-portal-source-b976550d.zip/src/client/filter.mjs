export function matchesEvidence(searchable, rowKind, query, selectedKind) {
  const terms = query.trim().toLowerCase().split(/\s+/).filter(Boolean);
  return (selectedKind === 'all' || selectedKind === rowKind) && terms.every(term => searchable.toLowerCase().includes(term));
}

export function initializeFilters(document) {
  const input = document.querySelector('#test-search');
  const select = document.querySelector('#test-kind');
  const rows = [...document.querySelectorAll('[data-test-row]')];
  if (!input || !select) return;
  const update = () => {
    let python = 0, node = 0;
    for (const row of rows) {
      row.hidden = !matchesEvidence(row.dataset.search, row.dataset.kind, input.value, select.value);
      if (!row.hidden) row.dataset.kind === 'python' ? python++ : node++;
    }
    document.querySelector('#filter-status').textContent = `${python} Python module${python === 1 ? '' : 's'} and ${node} Node case${node === 1 ? '' : 's'} shown.`;
    document.querySelector('#filter-empty').hidden = python + node > 0;
  };
  input.addEventListener('input', update);
  select.addEventListener('change', update);
  document.querySelector('#reset-filters').addEventListener('click', () => {
    input.value = ''; select.value = 'all'; update(); input.focus();
  });
  update();
}
