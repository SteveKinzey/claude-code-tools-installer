export async function copyText(text, clipboard) {
  if (!clipboard || typeof clipboard.writeText !== 'function') return false;
  try { await clipboard.writeText(text); return true; } catch { return false; }
}

export function initializeClipboard(document, navigator) {
  const status = document.querySelector('#copy-status');
  const dialog = document.querySelector('#copy-fallback');
  let timer;
  for (const button of document.querySelectorAll('[data-copy]')) {
    button.hidden = false;
    button.addEventListener('click', async () => {
      const target = document.getElementById(button.dataset.copy);
      const text = target?.textContent || '';
      const copied = await copyText(text, navigator.clipboard);
      clearTimeout(timer);
      if (copied) {
        status.textContent = 'Copied to clipboard.';
        timer = setTimeout(() => { status.textContent = ''; }, 4500);
      } else {
        status.textContent = 'Clipboard unavailable. Select the text below and copy manually.';
        const area = dialog.querySelector('textarea');
        area.value = text;
        if (typeof dialog.showModal === 'function') { dialog.showModal(); area.focus(); area.select(); }
        else { target.hidden = false; target.focus(); }
      }
    });
  }
  dialog.querySelector('button').addEventListener('click', () => { dialog.close(); status.textContent = ''; });
}
