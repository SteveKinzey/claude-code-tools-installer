import { code, panel, sectionHeading } from '../html.mjs';

const captionPath = '/captions/ccti-silent-installed-app-tour.en-d470a4db9fa36424.vtt';
const captionHash = 'd470a4db9fa3642491b8d52c32525f94a475fe4fce98dd7d87ff43f4db8a46d3';

export function overview() {
  return `<section id="overview" aria-labelledby="overview-title">
    <div class="record-label"><span class="status-dot" aria-hidden="true"></span>Recorded snapshot — not continuous monitoring</div>
    <p class="eyebrow intro-label">CCTI / VERIFICATION NOTEBOOK</p>
    <h1 id="overview-title">Verification<br><span>& Workflows.</span></h1>
    <p class="intro">A source-to-live evidence notebook for builders shipping cached media. Read what passed, what it actually proves, and where the evidence stops.</p>
    <div class="intro-links"><a class="primary-link" href="#workflow">Follow the recovery workflow <span aria-hidden="true">↗</span></a><a href="#captions">Inspect the caption receipt <span aria-hidden="true">↓</span></a></div>
    <div class="snapshot">
      <div class="snapshot-top"><div><p class="eyebrow">PRODUCTION CAPTION SNAPSHOT</p><h2>Four cues loaded.<br>Transcript matched.</h2></div><span class="pass-badge">Recorded pass</span></div>
      <p class="provenance">12 October 2026 · normal GETs 07:10:06–07:10:08 UTC · native Chrome 07:12:10–07:12:17 UTC</p>
      <dl class="facts"><div><dt>HTTP response</dt><dd>200 on both recorded hosts</dd></div><div><dt>Content type</dt><dd>${code('text/vtt; charset=utf-8')}</dd></div><div><dt>Caption payload</dt><dd>315 bytes · 4 English cues</dd></div><div><dt>Freshness policy</dt><dd>${code('public, max-age=600')}</dd></div></dl>
      <div class="identity"><span>ACTIVE RECORDED URL</span>${code(captionPath)}<span>CAPTION PAYLOAD SHA-256</span>${code(captionHash)}</div>
      <p class="snapshot-limit">This is saved production evidence, not a fresh check by this notebook. No availability probes, tests or telemetry are initiated by the website.</p>
    </div>
    <div class="boundary"><strong>Working workaround ≠ provider-wide MIME repair.</strong><p>Active consumers migrated to a versioned <code>/captions/</code> URL. The historical <code>/assets/*.vtt</code> MIME mapping is <strong>not proven fixed</strong>. The browser receipt covers caption playback and transcript only; analytics was blocked.</p></div>
    <details class="lineage"><summary>Source-to-publication lineage and scope</summary><dl class="stacked-facts"><div><dt>Caption source checkpoint</dt><dd>${code('aaa2d59141c27b92758d0d208a35980ef98bacb3')}</dd></div><div><dt>Reported published descendant</dt><dd>${code('e94447d0cafb36dcb917698746613eb156c6d644')}</dd></div><div><dt>Reported production deployment</dt><dd>${code('67508871')} · distinct from this notebook’s deployment</dd></div></dl><p>Saved review records source ancestry and the later successful rollout. Normal GET evidence and native browser acceptance are separate receipts. Neither fixture counts nor deployment status alone establish hosted caption behavior.</p></details>
  </section>`;
}

const steps = [
  ['Inventory the exact build', 'Start with the candidate’s emitted files. Bind paths, byte lengths and full digests before any network checks. Keep HTML transformation exceptions separate from media and code bytes.', 'node scripts/build.mjs\nnode scripts/check.mjs', 'Notebook build example · local, read-only validation'],
  ['Verify the asset contract', 'Check status, MIME, body signature/cues, bytes, digest and cache policy. HTTP 200 with SPA HTML at a JSON or VTT URL is a failure. Record redirects and transport failures instead of silently retrying.', 'python3 "$SKILL_DIR/scripts/build_asset_manifest.py" "$BUILD_DIR" \\\n  --output "$AUDIT_DIR/build-assets.json"\npython3 "$SKILL_DIR/scripts/verify_assets.py" \\\n  --base "$AUTHORIZED_ORIGIN" --manifest "$AUDIT_DIR/build-assets.json" \\\n  --manifest-only --output "$AUDIT_DIR/asset-check.json"', 'Manual run only · explicitly authorized target required'],
  ['Reconcile checkpoint lineage', 'Trace committed source to packaged bytes, the saved checkpoint and the reported deployment. Then compare the public entry’s references. A source checkpoint, accepted request or preview is not publication proof.', 'git show --stat "$SOURCE_SHA"\ngit merge-base --is-ancestor "$SOURCE_SHA" "$PUBLISHED_SHA"\ngit diff --check', 'Read-only Git evidence · exact repository and SHAs required'],
  ['Exercise isolated fixtures', 'Keep generic recovery fixtures separate from application source and production. Node HTTP cases bind ephemeral loopback ports; construction checks and deterministic models have narrower scopes.', 'python3 -m unittest discover -s "$SKILL_DIR/scripts" -p \'test_*.py\' -v\nEXPRESS_MODULE="$EXISTING_EXPRESS_ENTRY" \\\n  node --test "$SKILL_DIR/scripts/test_caption_route_prototype.mjs"', 'Manual local fixtures · no public requests'],
  ['Accept the actual hosted consumers', 'Only when a new run is authorized: verify a bounded normal GET contract and real native track readyState/cue activity plus transcript parity. Keep original failures, dated evidence and unrelated analytics noise separate.', 'python3 "$SKILL_DIR/scripts/verify_assets.py" \\\n  --base "$AUTHORIZED_ORIGIN" --manifest "$AUDIT_DIR/build-assets.json" \\\n  --manifest-only --output "$AUDIT_DIR/public-acceptance.json"', 'Public acceptance gate · not executed by this page']
];

export function workflow() {
  return `<section id="workflow">${sectionHeading('02', 'REUSABLE METHOD', 'From build to evidence.', 'Five gates. Separate claims at every boundary.')}
    <ol class="workflow-steps">${steps.map(([title, text, command, label], index) => `<li><span class="step-index">${index + 1}</span><div><h3>${title}</h3><p>${text}</p>${panel(`command-${index + 1}`, command, label)}</div></li>`).join('')}</ol>
    <details><summary>Dependencies, placeholders and execution boundaries</summary><p>Set <code>SKILL_DIR</code>, <code>BUILD_DIR</code>, <code>AUDIT_DIR</code>, exact commit SHAs and a separately authorized origin in your own environment. Quoted placeholders are not hidden production defaults.</p><p>Python helpers require Requests; metadata validation uses PyYAML. Optional native browser checks require Playwright/Chromium. Node prototype: Node 22+ and an existing Express 5 entry. Keep sibling scripts together because the manifest builder imports the verifier’s MIME definitions.</p><p>The prototype is a whole isolated Express application, not the production registrar. Its 3-second socket inactivity timeout is not a total deadline; shared port state assumes sequential cases. This notebook executes none of these commands.</p></details>
  </section>`;
}
