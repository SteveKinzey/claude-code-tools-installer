# CCTI Verification & Workflows — standalone website plan

## Outcome

A permanent, independently managed Manus-hosted reference site for the media-cache-recovery workflow, test-suite details, caption-route implementation and dated caption/transcript verification. It is a readable evidence notebook, not a monitoring service or a replacement for claudetool.app.

This chat is bound to the existing CCTI staging project. A supported initialization attempt for the separate site was rejected because each task can create at most one website project. Nothing was changed in staging. Creating this website therefore requires the user's approval to start a dedicated new task; do not repurpose the bound staging site or its declaration.

## Website content and interactions

1. **Verification overview.** Show the dated 2026-10-12 production caption outcome, exact MIME/byte/hash/cache facts and a prominent “Recorded snapshot — not continuous monitoring” label. Distinguish the working versioned /captions URL from the historical /assets MIME defect; do not claim the provider-wide MIME map is repaired.
2. **Recovery workflow.** A navigable guide through build inventory, asset-byte/MIME/cache verification, source-to-checkpoint lineage, local fixtures and production acceptance. Include copyable read-only commands, dependencies and clearly labelled gates. Do not execute requests, tests, deployments or analytics from the website.
3. **Test explorer.** Search/filter the 20 Python test modules and 36 Node cases; show the recorded 130 Python and 36 Node passing results with their dates and provenance. Explain that 30 Node cases use loopback HTTP, four are construction cases and two are deterministic models. Counts are not assertion totals or coverage percentages. Display the known assertion gaps, not just green pass badges.
4. **Caption evidence.** Display the four native cue times/texts and matching transcript entries. Provide an expandable full public-safe JSON viewer, copy action and download. The downloadable receipt is a labelled derivative of the original: remove response trace IDs and unrelated response-header details; preserve the original byte-identical local file. Give the derivative its own digest and never reuse the original file hash for changed bytes.
5. **Routing and cache analysis.** Explain the actual production source-file responsibilities, Express GET/HEAD/validator behavior and versioned-URL migration. Show the documented /captions/* server rule as a prescription, not proof of a rule that was read/applied. Explain that server cache:0 controls eligible server HTML caching, not the VTT TTL. Purge, fresh browser cache, validators and referring-client retention remain separate concerns.
6. **Downloads and sources.** Offer a public-safe workflow handbook, structured suite/assertion inventory and sanitized caption evidence. Use content-versioned filenames and display size/digest. Keep raw support history, private task links, local machine paths, credentials and original private archives out of the public site. The installed 59-file skill and its original archive remain untouched; do not publish the whole archive without a separate content review.

The portal uses real saved evidence. It will not run new production probes, contact telemetry endpoints, create support cases, or imply a current automated health check.

## Implementation approach

Use semantic static HTML, custom CSS and small JavaScript modules. No server, database, login, email integration, scheduled work or app analytics is needed. There are no secrets or live production APIs to configure. Content renders as readable HTML without JavaScript; JavaScript enhances filters, JSON disclosure and clipboard actions with fallbacks.

Keep the site in its dedicated directory `/Users/skinzey/code/claude-code-tools-installer/verification-site` if the approved task runs on this Desktop. If a cloud task is explicitly chosen, use its tool-returned project directory and transfer only the curated inputs with verified hashes; do not assume shared device paths exist there.

Configure a static build/output contract after successful new-project initialization. Fingerprint changing CSS, JavaScript, JSON and downloadable files before publication because static non-HTML output may receive the host's 90-day cache policy. The HTML selects the current fingerprinted files. Do not rely on route declarations alone as evidence of served cache headers. Commit only this website's source and public-safe assets to its own Managed Git; keep research logs, raw archives and local environment files outside the published output. The new project receives its own Manus hostname and version history; saving its versions uploads only the selected website code to Manus.

## Proposed project structure

```text
verification-site/
├── manus-webdev.json       tool-issued website identity; not invented
├── app.config.ts          durable official-logo metadata
├── plan.md                approved implementation/design plan
├── TODO.md                native-ToDo fallback with complete outcome criteria
├── README.md              local editing and independent publication instructions
├── content/               curated source data and handbook text
├── scripts/               deterministic static assembly/content validation
└── public/
    ├── index.html         complete readable single-page report with section anchors
    ├── manus-routes.json  actual page manifest, distinct from hosting routing
    ├── assets/            official icon, self-hosted fonts, fingerprinted CSS/JS
    ├── data/              fingerprinted public-safe evidence and suite data
    └── downloads/         fingerprinted handbook/inventory/evidence files
```

## Design

**Design movement:** restrained information design, combining an editorial technical notebook with the precision of a developer reference. The site is greenfield; it borrows the official CCTI icon rather than redesigning the marketing site.

**Core principles:** evidence before claims; provenance next to each result; progressive disclosure for dense code/JSON; keyboard-readable navigation and generous line lengths.

**Color philosophy:** an off-white paper surface with deep navy type; dark navy code panels; blue links and mint success accents derived from the existing CCTI icon. Color accompanies words such as “recorded pass,” “historical” and “not verified,” never replacing them. No decorative gradient or fake dashboard charts.

**Layout:** a left-hand contents rail and a wide editorial reading column on desktop, collapsing to a compact in-page contents disclosure on phones. Alternate concise fact rows, code panels and assertion tables rather than repeating a generic card grid.

**Signature elements:** numbered workflow steps, monospace evidence identifiers, small dated provenance labels and a clear historical-versus-active route comparison.

**Interaction:** immediate filters, native disclosure for JSON/details, copy buttons with explicit success/failure feedback and ordinary download links. Never use innerHTML to display receipt content. No auto-fetch of production endpoints. No animation is needed for evidence credibility.

**Animation:** short focus/hover/state transitions only; reduced-motion preferences respected. Avoid scroll-jacking and decorative entrance sequences.

**Typography:** Sora for section headlines, Source Sans 3 for readable body/table text and IBM Plex Mono for route/hash/code text, self-hosted with licence files. If acquisition is unavailable, use named local fallbacks without introducing a third-party runtime dependency. Headlines retain a strong hierarchy without pushing the evidence below a large marketing hero.

**Brand essence:** “A source-to-live evidence notebook for builders shipping cached media.” Personality: precise, transparent, practical. The heading is the descriptive project title, paired with the existing official CCTI icon; do not fabricate another logo.

**Voice examples:** “Recorded caption check: four cues loaded.” “130 passing fixtures are not a production availability guarantee.”

**Signature color:** the CCTI icon's mint, #72DAC7, used on dark surfaces for verified snapshot markers; light-surface text uses a darker accessible derivative.

**Design calibration:** variance 4, motion 2, density 7, imagery 2, brand fidelity 7. These translate to a stable contents rail, minimal motion, dense but disclosed technical detail and reuse of the real icon without extra illustrations.

## Scope and publication

The site is separate from the installer repository's runtime, the production marketing site and static staging. No DNS, proxy-trust, edge mapping, cache purge, source deployment or settings change is made to those existing environments. No telemetry traffic is replayed. TRUST_PROXY_HOPS remains unset.

The requested permanent hosting will use the new project's supported checkpoint and publish workflow. Respect its own publication confirmation flow; never enable auto-publish silently. Do not describe a preview, saved checkpoint or accepted publish request as a successfully published permanent website. Keep the dated production evidence separate from any checks performed on this new portal.

## Source inputs

- `outputs/test-assertion-review-20261012/exact-suite-and-node-assertion-review.md`
- `outputs/routing-skill-slides-review-20261012/production-native-caption-transcript.json`
- `outputs/routing-skill-slides-review-20261012/routing-and-reusable-skill-review.md`
- Installed `ccti-bundled-media-cache-recovery` for read-only workflow/code review, not automatic publication of its private archive.
- Official icon: `claude-code-tools-installer-site/client/public/manus-storage/ccti-icon_dc61d99c.svg`
- [MDN Cache-Control](https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/Cache-Control)
- [web.dev HTTP cache guidance](https://web.dev/articles/http-cache)

Approved by Steve on 2026-10-13 03:17 UTC. Implementation and publication authorized in the dedicated website task. Historical pending and parent-binding text above records earlier planning context, not a current blocker.
