# CCTI Verification & Workflows

A source-to-live evidence notebook for builders shipping cached media.

**Recorded snapshot — not continuous monitoring.** Production evidence below was captured on 12 October 2026. This handbook initiates no requests, deployments, tests or telemetry.

## Recorded caption outcome

Normal GETs at 07:10:06–07:10:08 UTC on the CCTI apex and its managed alias returned HTTP 200, text/vtt; charset=utf-8, public, max-age=600 and 315 bytes. Payload SHA-256: d470a4db9fa3642491b8d52c32525f94a475fe4fce98dd7d87ff43f4db8a46d3.

Active recorded URL: /captions/ccti-silent-installed-app-tour.en-d470a4db9fa36424.vtt.

Native Chrome 154.0.8037.98 acceptance at 07:12:10–07:12:17 UTC recorded four native cues, track readyState2/showing, an active caption and four matching transcript entries. Video: 1920×1080, readyState4, duration 8 seconds; both caption responses 200 text/vtt; no caption request failures. Analytics was blocked. This is not a whole-site or analytics acceptance claim.

The new /captions URL migrated active consumers. The old /assets VTT MIME mapping is **not proven fixed**. Caption source aaa2d59141c27b92758d0d208a35980ef98bacb3 is an ancestor of reported published e94447d0cafb36dcb917698746613eb156c6d644, production deployment67508871. These production identifiers are not the notebook’s publication identity.

## Recovery workflow

### 1. Inventory the exact build

Bind each emitted file to its relative path, MIME expectation, byte length and full SHA-256. Gateway HTML transformations may require a labelled exception; do not apply that exception to media/code. Preserve the failing baseline.

### 2. Verify byte, MIME and cache contracts

Status200 alone is insufficient. Reject SPA HTML at VTT/JSON URLs. Check MIME, nonempty bytes, digest/size, WebVTT signature/cues, redirects and cache directives. Validate the whole plan before traffic. Use a bounded, explicitly authorized target and preserve transport failures without automatic retries.

```bash
python3 "$SKILL_DIR/scripts/build_asset_manifest.py" "$BUILD_DIR" --output "$AUDIT_DIR/build-assets.json"
python3 "$SKILL_DIR/scripts/verify_assets.py" --base "$AUTHORIZED_ORIGIN" --manifest "$AUDIT_DIR/build-assets.json" --manifest-only --output "$AUDIT_DIR/asset-check.json"
```

### 3. Reconcile source-to-checkpoint lineage

Trace exact committed source, packaged output, saved checkpoint, reported deployment and public entry references independently.

```bash
git show --stat "$SOURCE_SHA"
git merge-base --is-ancestor "$SOURCE_SHA" "$PUBLISHED_SHA"
git diff --check
```

A preview, source-only success, accepted publish request or fixture pass is not a successful public deployment.

### 4. Exercise local fixtures

```bash
python3 -m unittest discover -s "$SKILL_DIR/scripts" -p 'test_*.py' -v
EXPRESS_MODULE="$EXISTING_EXPRESS_ENTRY" node --test "$SKILL_DIR/scripts/test_caption_route_prototype.mjs"
```

Python HTTP helpers use Requests, metadata validation PyYAML; optional browser checks use Playwright/Chromium. Node prototype requires Node 22+ and an existing Express 5 entry. Keep sibling scripts together. Variables are manual placeholders, not embedded credentials or default targets. Node loopback clients have a 3-second socket inactivity timeout, not total deadline; shared port state assumes sequential cases.

### 5. Accept real hosted consumers

Only when a new run is explicitly authorized: verify bounded normal GETs and real native track cue loading/activity plus matching transcript. Keep app source tests, generic fixtures, public HTTP and browser acceptance as separate receipts. Never overwrite a historical failure with a later pass. The notebook does not run these checks.

## Recorded suite scopes

130 Python cases across 20 modules; 36 Node cases: 30 loopback HTTP, 4 construction, 2 deterministic models. Saved installed logs are dated 12 October 2026, not rerun by this portal. Python: 13.826 seconds; Node: 792.183958 ms. Counts are not assertion totals, line/branch coverage or percentages.

full(response):200, exact MIME/cache/full ETag/nosniff/Content-Length 315, no cookie/encoding/Vary and exact 315-byte SHA. conditional(response):304, empty body, exact ETag/cache, no cookie; no universal Content-Type-on 304 requirement. negative(response,status):exact rejection status/no-store/text/plain UTF-8/no cookie or ETag/no literal <html>.

Case 34 checks old version fully, new version only 200 + SHA; no explicit changed-byte/digest assertion. HEAD/error nosniff/variant/CORS assertions are not uniform. Construction misses some oversized/UTF-8/dependency/empty-registry branches. Startup throws are not request-time500 behavior; LF cue regex is not general WebVTT grammar. No global middleware, service worker, edge, frontend trust or production HEAD/304/error proof. No coverage instrumentation recorded. Python urllib3/LibreSSL warning does not qualify that runtime for public HTTPS. These are review gaps, not observed production failures.

## Exact production responsibilities

shared/captions.ts:trusted digest/size/path. server/captionRoutes.ts:allowlisted GET/HEAD/validators/MIME/cache/non-HTML errors. server/_core/index.ts:registration before fallback. scripts/package-caption-route.mjs:package beside server. client/src/lib/media.ts:shared active track/transcript URL and old bundled artifact. client/src/components/VideoTranscript.tsx:narrow trusted-source acceptance. server/captionRoutes.test.ts:app-specific assertions. dist/captions/ccti-silent-installed-app-tour.en-d470a4db9fa36424.vtt:packaged bytes, resolved relative to the server bundle, not process cwd.

The skill prototype is a whole isolated Express test app, **not** production middleware. It validates bytes, snapshots a Buffer into a Map, claims namespace/methods before SPA fallback and uses Expresssend/fresh behavior. Strong/weak/list/wildcard validators, bodyless HEAD/304 and unknown-version errors have their stated fixture scope. Range returns full 200, not 206. No Last-Modified is emitted; ETag-versus-date is not complete date-validator coverage.

## Routing and cache analysis

Supported prescription, **not applied-rule evidence**:

```json
{"path":"/captions/*","target":"server","cache":0}
```

The effective production rule table was not read or written. allRoutes/manus-routes.json are page metadata. If a future routing change is needed, verify exact project identity/read complete config and preserve all ordered rules in a reviewed full-domain merge. Do not rewrite a working production route merely to match this prescription.

server cache:0 concerns eligible HTML caching, not VTT TTL. The observed response’s public, max-age=600 is a freshness policy, not HIT/residency/capacity/latency/cost proof. Age reduces remaining freshness. ETag saves body retransmission, not all request overhead; same-body 304 alone does not prove old wrong MIME replaced.

Purging before fixing MIME can refill the error. CDN purge cannot clear fresh browser copies. TTL/no-store changes are not retroactive. Transcript fetch cache options do not control native track or platform lookup. Clear-Site-Data is origin-wide, not caption-specific; no purge was performed.

New bytes use new digest-bound URLs; existing versions never change. Retain caption versions through the supported referring-client horizon, not merely ten minutes. Cached bundles, open tabs and supported historical/offline references may refetch old versions. No service worker presence is claimed. Immutable applies while fresh, not indefinitely. Asymmetric max-age/s-maxage strategies require actual hosting evidence and explicit product acceptance, not a schema inference.

## Derivative evidence

Public JSON retains native cues/transcript and selected MIME/cache/ETag/length/date/nosniff headers. Trace IDs and unrelated headers are removed. Each derivative is separately byte-hashed; original receipt hashes are provenance only, never reused as derivative identity. Original raw receipts/private histories/task links/machine paths/credentials/skill archives are not published.

## Sources

- [MDN Cache-Control](https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/Cache-Control)
- [web.dev HTTP cache](https://web.dev/articles/http-cache) — updated2018-11-05; current MDN governs normative wording.
- [Official CCTI product site](https://claudetool.app/)
- [CCTI installer source](https://github.com/SteveKinzey/claude-code-tools-installer)

Cache sources checked 13 October 2026. Production receipts remain dated 12 October 2026. This standalone notebook has no server, database, login, AI, email, analytics or scheduler and modifies none of those production systems.
