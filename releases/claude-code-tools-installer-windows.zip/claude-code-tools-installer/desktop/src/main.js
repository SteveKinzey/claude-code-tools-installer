const { app, BrowserWindow, ipcMain } = require('electron');
const { spawn } = require('node:child_process');
const fs = require('node:fs/promises');
const path = require('node:path');

let mainWindow;
let activeInstall = false;

function installerResource(...segments) {
  const base = app.isPackaged ? process.resourcesPath : path.resolve(__dirname, '..', '..');
  return path.join(base, app.isPackaged ? 'installers' : '', ...segments);
}

function catalogResource() {
  return app.isPackaged
    ? path.join(process.resourcesPath, 'catalog.json')
    : path.resolve(__dirname, '..', 'catalog.json');
}

function installerDefinition() {
  if (process.platform === 'darwin') {
    return { command: 'bash', script: installerResource('setup-my-claude.sh'), args: [] };
  }
  if (process.platform === 'win32') {
    return { command: 'pwsh.exe', script: installerResource('setup-my-claude.ps1'), args: ['-File'] };
  }
  return { command: 'bash', script: installerResource('setup-my-claude-linux.sh'), args: [] };
}

function emit(channel, payload) {
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send(channel, payload);
  }
}

function spawnInstaller(mode, selectedIds = [], dryRun = false) {
  const definition = installerDefinition();
  const args = [...definition.args, definition.script];

  if (mode === 'bootstrap') {
    args.push(process.platform === 'win32' ? '-BootstrapOnly' : '--bootstrap-only');
  } else {
    args.push(process.platform === 'win32' ? '-Yes' : '--yes');
    if (selectedIds.length > 0) {
      args.push(process.platform === 'win32' ? '-Item' : '--item', selectedIds.join(','));
    }
  }
  if (dryRun) {
    args.push(process.platform === 'win32' ? '-DryRun' : '--dry-run');
  }

  return new Promise((resolve, reject) => {
    const child = spawn(definition.command, args, {
      cwd: app.getPath('home'),
      windowsHide: true,
      env: { ...process.env },
    });

    child.stdout.on('data', (chunk) => emit('installer:output', { stream: 'stdout', text: chunk.toString() }));
    child.stderr.on('data', (chunk) => emit('installer:output', { stream: 'stderr', text: chunk.toString() }));
    child.on('error', (error) => reject(new Error(`Could not start ${definition.command}: ${error.message}`)));
    child.on('close', (code) => resolve({ code, args }));
  });
}

async function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1200,
    height: 820,
    minWidth: 980,
    minHeight: 700,
    backgroundColor: '#0b1020',
    title: 'Claude Code Tools Installer',
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      preload: path.join(__dirname, 'preload.js'),
    },
  });

  await mainWindow.loadFile(path.join(__dirname, 'renderer', 'index.html'));
}

app.whenReady().then(async () => {
  ipcMain.handle('catalog:get', async () => {
    const raw = await fs.readFile(catalogResource(), 'utf8');
    return JSON.parse(raw);
  });

  ipcMain.handle('bootstrap:start', async () => {
    try {
      const result = await spawnInstaller('bootstrap');
      return { ok: result.code === 0, code: result.code };
    } catch (error) {
      return { ok: false, error: error.message };
    }
  });

  ipcMain.handle('install:run', async (_event, { selectedIds, dryRun }) => {
    if (activeInstall) {
      return { ok: false, error: 'An installation is already running.' };
    }
    if (!Array.isArray(selectedIds) || selectedIds.length === 0) {
      return { ok: false, error: 'Choose at least one tool before continuing.' };
    }

    activeInstall = true;
    emit('installer:state', { running: true });
    try {
      const result = await spawnInstaller('install', selectedIds, Boolean(dryRun));
      return { ok: result.code === 0, code: result.code };
    } catch (error) {
      return { ok: false, error: error.message };
    } finally {
      activeInstall = false;
      emit('installer:state', { running: false });
    }
  });

  await createWindow();
  app.on('activate', async () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      await createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});
