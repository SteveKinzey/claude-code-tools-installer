const state = {
  catalog: [],
  selected: new Set(),
  running: false,
};

const catalogElement = document.querySelector('#catalog');
const outputElement = document.querySelector('#output');
const summaryElement = document.querySelector('#selection-summary');
const installDescriptionElement = document.querySelector('#install-description');
const installButton = document.querySelector('#install-button');
const runStatusElement = document.querySelector('#run-status');
const bootstrapStatusElement = document.querySelector('#bootstrap-status');

function selectedItems() {
  return state.catalog.filter((tool) => state.selected.has(tool.id));
}

function appendOutput(text, stream = 'stdout') {
  outputElement.textContent += text;
  outputElement.classList.toggle('has-error', stream === 'stderr');
  outputElement.scrollTop = outputElement.scrollHeight;
}

function updateSummary() {
  const selected = selectedItems();
  const recommendedCount = selected.filter((tool) => tool.default).length;
  summaryElement.textContent = `${selected.length} of ${state.catalog.length} tools selected${recommendedCount ? `, including ${recommendedCount} recommended` : ''}.`;
  installDescriptionElement.textContent = selected.length
    ? `You will ${document.querySelector('#dry-run').checked ? 'preview' : 'install'} ${selected.length} selected tool${selected.length === 1 ? '' : 's'}. Claude Code is handled first, then the platform installer applies this exact selection.`
    : 'Select tools to see the installation plan.';
  installButton.disabled = state.running || selected.length === 0;
}

function renderCatalog() {
  const categories = [...new Set(state.catalog.map((tool) => tool.category))];
  catalogElement.replaceChildren();

  for (const category of categories) {
    const tools = state.catalog.filter((tool) => tool.category === category);
    const section = document.createElement('section');
    section.className = 'category-section';
    section.innerHTML = `<div class="category-heading"><h3>${category}</h3><span>${tools.length} tools</span></div>`;

    const grid = document.createElement('div');
    grid.className = 'tool-grid';
    for (const tool of tools) {
      const card = document.createElement('label');
      card.className = 'tool-card';
      const input = document.createElement('input');
      input.type = 'checkbox';
      input.checked = state.selected.has(tool.id);
      input.addEventListener('change', () => {
        if (input.checked) state.selected.add(tool.id);
        else state.selected.delete(tool.id);
        renderCatalog();
        updateSummary();
      });

      const body = document.createElement('span');
      body.className = 'tool-card-body';
      body.innerHTML = `<span class="tool-title">${tool.name}${tool.default ? '<span class="recommended">Recommended</span>' : ''}</span><span class="tool-classification">${tool.classification}</span><span class="tool-action">${tool.action}</span>`;
      card.append(input, body);
      grid.append(card);
    }
    section.append(grid);
    catalogElement.append(section);
  }
}

async function startBootstrap() {
  appendOutput('Checking Claude Code and starting background preparation…\n');
  const result = await window.installer.startBootstrap();
  if (result.ok) {
    bootstrapStatusElement.textContent = 'Claude Code ready or preparing';
    bootstrapStatusElement.className = 'status-chip status-ready';
  } else {
    bootstrapStatusElement.textContent = 'Claude Code needs attention';
    bootstrapStatusElement.className = 'status-chip status-error';
    appendOutput(`${result.error || `Claude Code preparation exited with code ${result.code}`}.\n`, 'stderr');
  }
}

async function runInstallation() {
  const selected = selectedItems();
  const preview = document.querySelector('#dry-run').checked;
  const action = preview ? 'preview' : 'install';
  const names = selected.map((tool) => `• ${tool.name}`).join('\n');
  if (!window.confirm(`Confirm ${action} for ${selected.length} tool(s)?\n\n${names}\n\nClaude Code is prepared first. Plugin commands and credential-sensitive tools may produce instructions rather than silent setup.`)) {
    return;
  }

  outputElement.textContent = '';
  appendOutput(`${preview ? 'Previewing' : 'Installing'} ${selected.length} selected tools…\n`);
  const result = await window.installer.runInstall({ selectedIds: selected.map((tool) => tool.id), dryRun: preview });
  if (result.ok) {
    appendOutput(`\n${preview ? 'Preview' : 'Installation'} completed successfully.\n`);
    runStatusElement.textContent = preview ? 'Preview complete' : 'Installation complete';
  } else {
    appendOutput(`\nThe installer stopped: ${result.error || `exit code ${result.code}`}. Review the log output above.\n`, 'stderr');
    runStatusElement.textContent = 'Needs review';
  }
}

function chooseBy(predicate) {
  state.selected = new Set(state.catalog.filter(predicate).map((tool) => tool.id));
  renderCatalog();
  updateSummary();
}

document.querySelector('#recommended-button').addEventListener('click', () => chooseBy((tool) => tool.default));
document.querySelector('#all-button').addEventListener('click', () => chooseBy(() => true));
document.querySelector('#clear-button').addEventListener('click', () => chooseBy(() => false));
document.querySelector('#dry-run').addEventListener('change', updateSummary);
document.querySelector('#install-button').addEventListener('click', runInstallation);

window.installer.onOutput(({ stream, text }) => appendOutput(text, stream));
window.installer.onState(({ running }) => {
  state.running = running;
  runStatusElement.textContent = running ? 'Installer running' : 'Ready';
  updateSummary();
});

(async () => {
  try {
    state.catalog = await window.installer.getCatalog();
    chooseBy((tool) => tool.default);
    await startBootstrap();
  } catch (error) {
    bootstrapStatusElement.textContent = 'App setup failed';
    bootstrapStatusElement.className = 'status-chip status-error';
    appendOutput(`${error.message}\n`, 'stderr');
  }
})();
