const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('installer', {
  getCatalog: () => ipcRenderer.invoke('catalog:get'),
  startBootstrap: () => ipcRenderer.invoke('bootstrap:start'),
  runInstall: (payload) => ipcRenderer.invoke('install:run', payload),
  onOutput: (callback) => ipcRenderer.on('installer:output', (_event, payload) => callback(payload)),
  onState: (callback) => ipcRenderer.on('installer:state', (_event, payload) => callback(payload)),
});
